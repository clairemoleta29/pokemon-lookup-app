# Pokémon Lookup App

**IT 126 – Module 3, Lesson 4: Communicating with Services**

## Project Description

Pokémon Lookup is a simple Flutter application that retrieves Pokémon information from the public PokeAPI. The user enters a Pokémon name, and the application sends an HTTP GET request to retrieve its information.

## Features

- Search for a Pokémon by name.
- Display the Pokémon's name, ID, height, weight, abilities, types, and image.
- Show a loading indicator while the request is running.
- Display an error message when a Pokémon is not found or the network is unavailable.
- Disable the search button while a request is in progress.

## Technologies

- Flutter and Dart
- `http` package for HTTP requests
- `dart:convert` and `jsonDecode()` for decoding JSON
- PokeAPI: https://pokeapi.co/

## How to Run

1. Install Flutter and an Android emulator or connect an Android device.
2. Open this project folder in VS Code.
3. Run `flutter pub get` in the terminal.
4. Run `flutter run`.

If you are creating a fresh Flutter project and copying these files into it, add the package with:

```bash
flutter pub add http
```

For Android, make sure internet permission is present in
`android/app/src/main/AndroidManifest.xml`, above the `<application>` tag:

```xml
<uses-permission android:name="android.permission.INTERNET" />
```

## How the Application Communicates with the API

The application uses this endpoint pattern:

`https://pokeapi.co/api/v2/pokemon/{name}`

The entered Pokémon name replaces `{name}`. The `http.get()` method sends a GET request. When the server returns status code 200, the application decodes the response body with `jsonDecode()` and converts the result into a `Pokemon` object using the `Pokemon.fromJson()` factory constructor.

## Error Handling

- **Successful request (200):** The application decodes the JSON response and displays the Pokémon details.
- **Pokémon not found (404):** The application displays a message asking the user to check the Pokémon name.
- **Network or timeout failure:** The application displays a message asking the user to check the internet connection and try again.
- **Unexpected response or data:** The application displays a general processing error instead of trying to show invalid information.
- **Loading state:** The application displays a progress indicator and disables the search button until the request finishes.

## Proposed Offline Strategy

This version does not implement local database storage or synchronization, as required by the activity constraints. In a future version, previously retrieved Pokémon information could be saved locally using a local database or cache. When the device is offline, the application could show the saved information and tell the user that it may be outdated. When the internet connection becomes available again, the user could refresh the information from the API.

## API Source

PokeAPI: https://pokeapi.co/api/v2/pokemon/pikachu
