import 'package:flutter/material.dart';
import 'models/pokemon.dart';
import 'services/pokemon_service.dart';

void main() {
  runApp(const PokemonLookupApp());
}

class PokemonLookupApp extends StatelessWidget {
  const PokemonLookupApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Pokémon Lookup',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFE53935)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF7F7F7),
      ),
      home: const PokemonHomePage(),
    );
  }
}

class PokemonHomePage extends StatefulWidget {
  const PokemonHomePage({super.key});

  @override
  State<PokemonHomePage> createState() => _PokemonHomePageState();
}

class _PokemonHomePageState extends State<PokemonHomePage> {
  final TextEditingController _controller = TextEditingController();
  final PokemonService _pokemonService = PokemonService();

  Pokemon? _pokemon;
  bool _isLoading = false;
  String? _errorMessage;

  Future<void> _searchPokemon() async {
    final name = _controller.text.trim().toLowerCase();

    if (name.isEmpty || _isLoading) return;

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _pokemon = null;
    });

    try {
      final result = await _pokemonService.fetchPokemon(name);
      if (!mounted) return;
      setState(() {
        _pokemon = result;
        _isLoading = false;
      });
    } on PokemonNotFoundException {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Pokémon not found. Please check the name and try again.';
        _isLoading = false;
      });
    } on PokemonNetworkException {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Unable to connect. Check your internet connection and try again.';
        _isLoading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'The response could not be processed. Please try again.';
        _isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Pokémon Lookup',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: const Color(0xFFE53935),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 12),
              const Icon(Icons.catching_pokemon, size: 72, color: Color(0xFFE53935)),
              const SizedBox(height: 8),
              const Text(
                'Find Your Pokémon!',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                'Enter a Pokémon name to view its information.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.black54),
              ),
              const SizedBox(height: 24),
              TextField(
                controller: _controller,
                textInputAction: TextInputAction.search,
                onSubmitted: (_) => _searchPokemon(),
                decoration: InputDecoration(
                  hintText: 'Example: pikachu',
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                height: 50,
                child: ElevatedButton.icon(
                  onPressed: _isLoading ? null : _searchPokemon,
                  icon: const Icon(Icons.search),
                  label: const Text('Search Pokémon'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFE53935),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              if (_isLoading)
                const Padding(
                  padding: EdgeInsets.all(28),
                  child: Column(
                    children: [
                      CircularProgressIndicator(),
                      SizedBox(height: 12),
                      Text('Loading Pokémon information...'),
                    ],
                  ),
                ),
              if (_errorMessage != null) _buildMessage(_errorMessage!, isError: true),
              if (_pokemon != null) _buildPokemonCard(_pokemon!),
              if (!_isLoading && _pokemon == null && _errorMessage == null)
                const Padding(
                  padding: EdgeInsets.all(18),
                  child: Text(
                    'Try searching for Pikachu, Bulbasaur, or Charizard.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.black54),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMessage(String message, {required bool isError}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isError ? Colors.red.shade50 : Colors.green.shade50,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        message,
        textAlign: TextAlign.center,
        style: TextStyle(
          color: isError ? Colors.red.shade800 : Colors.green.shade800,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }

  Widget _buildPokemonCard(Pokemon pokemon) {
    return Card(
      elevation: 2,
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          children: [
            if (pokemon.imageUrl.isNotEmpty)
              Image.network(
                pokemon.imageUrl,
                height: 160,
                width: 160,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => const Icon(
                  Icons.catching_pokemon,
                  size: 120,
                  color: Colors.grey,
                ),
              ),
            Text(
              pokemon.name[0].toUpperCase() + pokemon.name.substring(1),
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
            ),
            Text(
              '#${pokemon.id.toString().padLeft(3, '0')}',
              style: const TextStyle(color: Colors.black54, fontSize: 16),
            ),
            const Divider(height: 28),
            Row(
              children: [
                Expanded(child: _detailTile('Height', '${pokemon.height / 10} m')),
                Expanded(child: _detailTile('Weight', '${pokemon.weight / 10} kg')),
              ],
            ),
            const SizedBox(height: 18),
            _infoSection('Types', pokemon.types),
            const SizedBox(height: 14),
            _infoSection('Abilities', pokemon.abilities),
          ],
        ),
      ),
    );
  }

  Widget _detailTile(String label, String value) {
    return Column(
      children: [
        Text(label, style: const TextStyle(color: Colors.black54)),
        const SizedBox(height: 5),
        Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      ],
    );
  }

  Widget _infoSection(String title, List<String> values) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: values.map((value) {
            return Chip(label: Text(value[0].toUpperCase() + value.substring(1)));
          }).toList(),
        ),
      ],
    );
  }
}
