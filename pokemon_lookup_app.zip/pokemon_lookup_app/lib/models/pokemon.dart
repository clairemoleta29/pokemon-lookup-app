class Pokemon {
  final int id;
  final String name;
  final int height;
  final int weight;
  final String imageUrl;
  final List<String> abilities;
  final List<String> types;

  const Pokemon({
    required this.id,
    required this.name,
    required this.height,
    required this.weight,
    required this.imageUrl,
    required this.abilities,
    required this.types,
  });

  factory Pokemon.fromJson(Map<String, dynamic> json) {
    final sprites = json['sprites'] as Map<String, dynamic>? ?? {};
    final officialArtwork = sprites['other'] as Map<String, dynamic>? ?? {};
    final artwork = officialArtwork['official-artwork'] as Map<String, dynamic>? ?? {};

    final abilityList = (json['abilities'] as List<dynamic>? ?? [])
        .map((item) => (item['ability'] as Map<String, dynamic>)['name'] as String)
        .toList();

    final typeList = (json['types'] as List<dynamic>? ?? [])
        .map((item) => (item['type'] as Map<String, dynamic>)['name'] as String)
        .toList();

    return Pokemon(
      id: json['id'] as int,
      name: json['name'] as String,
      height: json['height'] as int,
      weight: json['weight'] as int,
      imageUrl: (artwork['front_default'] ?? sprites['front_default'] ?? '') as String,
      abilities: abilityList,
      types: typeList,
    );
  }
}
