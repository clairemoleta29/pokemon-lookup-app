import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../models/pokemon.dart';

class PokemonNotFoundException implements Exception {}

class PokemonNetworkException implements Exception {}

class PokemonService {
  Future<Pokemon> fetchPokemon(String name) async {
    final url = Uri.parse('https://pokeapi.co/api/v2/pokemon/$name');

    try {
      final response = await http.get(url).timeout(const Duration(seconds: 15));

      if (response.statusCode == 404) {
        throw PokemonNotFoundException();
      }

      if (response.statusCode != 200) {
        throw Exception('Server returned status code ${response.statusCode}');
      }

      final decoded = jsonDecode(response.body);

      if (decoded is! Map<String, dynamic>) {
        throw const FormatException('Unexpected response format.');
      }

      return Pokemon.fromJson(decoded);
    } on PokemonNotFoundException {
      rethrow;
    } on TimeoutException {
      throw PokemonNetworkException();
    } on http.ClientException {
      throw PokemonNetworkException();
    } on FormatException {
      rethrow;
    } catch (error) {
      if (error is Exception && error.toString().contains('SocketException')) {
        throw PokemonNetworkException();
      }
      rethrow;
    }
  }
}
